function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    }
    else if (input == "i'm scared") {
        let t1="What makes you beautitiful-One Direction"
       return t1.link("C:/Users/91944/Music/Playlists/what makes.mp3");
    }
    else if (input == "i'm happy") {
        let t1="On The Floor-Jennifer Lopez"
       return t1.link("C:/Users/91944/Music/Playlists/on the floor.mp3");
    }
    else if (input == "i'm sad") {
        let t1="Ok Not To Be Okay-Demi Lovato"
       return t1.link("C:/Users/91944/Music/Playlists/its ok.mp3");
    }
    else if (input == "recommend any other song") {
        let t1="Perfect-Ed Sheeran"
       return t1.link("C:/Users/91944/Music/Playlists/perfect.mp3");
    }
    else if (input == "play me a song"){
        return "How you are feeling?"
    }
     else {
        return "Try asking something else!";
    }
}